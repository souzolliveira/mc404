void my_print(int number);
int my_sum(int A, int B);

int main(int argc, char* argv[])
{
  int sum;
  sum = my_sum(400, 4);
  my_print(sum);
} 
