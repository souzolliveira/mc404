#include<stdio.h>

void my_print(int number)
{
  printf("%d rocks\n", number);
}
